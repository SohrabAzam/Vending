package com.pack.controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.model.Bowler;

/**
 * Servlet implementation class BowlerServlet
 */
public class BowlerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BowlerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		List<Bowler> bowlers = new ArrayList<>();
		int id = 0;
		String name = null;
		int runsConceded = 0;
		int overs = 0;
		
		for(int i=1;i<6;i++) {
			Bowler bowler= new Bowler();
			id = i;
			name = request.getParameter("name"+id);
			runsConceded = Integer.parseInt(request.getParameter("runs"+id));
			overs = Integer.parseInt(request.getParameter("overs"+id));
			bowler.setId(id);
			bowler.setName(name);
			bowler.setRunsConceded(runsConceded);
			bowler.setOvers(overs);
			bowler.calculateEconomy();
			bowlers.add(bowler);
		}
		try {
			File file = new File("C:\\Users\\761214\\Desktop\\output.txt");
			FileWriter fileWriter = new FileWriter(file);
					
			for(Bowler bowler : bowlers) {
				String s = bowler.toString();
				System.out.println(s);
				fileWriter.write(s+System.getProperty( "line.separator" ));
				
				
			}
			fileWriter.write(System.getProperty( "line.separator" ));
			fileWriter.flush();
			fileWriter.close();
		}
		
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
		rd.include(request, response);
		pw.close();
	}

}
