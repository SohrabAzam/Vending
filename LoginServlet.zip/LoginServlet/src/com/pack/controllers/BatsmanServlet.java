package com.pack.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.model.Batsman;

/**
 * Servlet implementation class BatsmanServlet
 */
public class BatsmanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BatsmanServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("Hello");
		List<Batsman> batsmen = new ArrayList<>();
		int id = 0;
		String name = null;
		int runs = 0;
		int balls = 0;
		
		for(int i=1;i<6;i++) {
			Batsman batsman = new Batsman();
			id = i;
			name = request.getParameter("name"+id);
			runs = Integer.parseInt(request.getParameter("runs"+id));
			balls = Integer.parseInt(request.getParameter("balls"+id));
			batsman.setId(id);
			batsman.setName(name);
			batsman.setRuns(runs);
			batsman.setBalls(balls);
			batsman.calculateStrikeRate();
			batsmen.add(batsman);
		}
		
		request.setAttribute("batsmen", batsmen);	
		for(Batsman batsman:batsmen) {
			System.out.println(batsman.getName());
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("batsmanResult.jsp");
		rd.forward(request, response);
		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
