package com.pack.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pack.dao.LoginDao;
import com.pack.model.User;

import encryption.Encryptor;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		LoginDao login = new LoginDao();
		User user = new User();
		user.setUsername(username);
		user.setPassword(Encryptor.getMD5EncryptedValue(password));
		
		try {
			User authenticatedUser = login.validate(user);
			if (authenticatedUser != null) {
				
				HttpSession session = request.getSession();
				session.setAttribute("user", authenticatedUser);
				session.setMaxInactiveInterval(60*10);
				Cookie userName = new Cookie("user", authenticatedUser.getUsername());
				userName.setMaxAge(60*10);
				response.addCookie(userName);
				String encodedUrl = response.encodeRedirectURL("welcome.jsp");
				System.out.println("encoded url="+encodedUrl);
				response.sendRedirect(encodedUrl);
				/*
				 * RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
				 * rd.forward(request, response);
				 */
			}
			else {
				ResourceBundle resource = ResourceBundle.getBundle("message");
				String errorMessage = resource.getString("invalid");
				pw.println(errorMessage);
				RequestDispatcher rd = request.getRequestDispatcher("login.html");
				rd.include(request, response);
			}
		}
		catch (SQLException e) {
			System.out.println(e);
		}
		pw.close();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
