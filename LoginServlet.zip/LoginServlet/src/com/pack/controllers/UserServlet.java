package com.pack.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.dao.UserDao;
import com.pack.model.User;
import com.pack.model.comparators.FirstNameComparator;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public String fn="asc";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		UserDao dao = new UserDao();
		Comparator<User> p = new FirstNameComparator();
		try {
			List<User> users = dao.getUsers();

			/*
			 * Collections.sort(users, new Comparator<User>() {
			 * 
			 * @Override public int compare(User o1, User o2) { return
			 * o1.getFirstName().compareTo(o2.getFirstName()); } });
			 */
			Collections.sort(users, new FirstNameComparator());
			
			
			request.setAttribute("users", users);
			RequestDispatcher rd = request.getRequestDispatcher("users.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
