package com.pack.exceptions;

public class InvalidEmailException extends Exception{
	public InvalidEmailException(String s) {
		super(s);
	}
}
