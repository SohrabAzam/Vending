package com.pack.exceptions;

public class InvalidNameException extends Exception{
	public InvalidNameException(String s){
		super(s);
	}
}
