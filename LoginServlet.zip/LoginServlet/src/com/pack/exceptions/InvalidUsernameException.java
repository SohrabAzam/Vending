package com.pack.exceptions;

public class InvalidUsernameException extends Exception {
	public InvalidUsernameException(String s ) {
		super(s);
	}
}
