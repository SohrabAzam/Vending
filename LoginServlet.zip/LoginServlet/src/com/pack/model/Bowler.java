package com.pack.model;

import java.io.Serializable;

public class Bowler implements Serializable{
	private int id;
	private String name;
	private int runsConceded;
	private int overs;
	private double economy;

	public Bowler() {
		runsConceded = 0;
		overs = 0;
	}

	public Bowler(int id, String name, int runsConceded, int overs, double economy) {
		super();
		this.id = id;
		this.name = name;
		this.runsConceded = runsConceded;
		this.overs = overs;
		this.economy = economy;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRunsConceded() {
		return runsConceded;
	}

	public void setRunsConceded(int runsConceded) {
		this.runsConceded = runsConceded;
	}

	public int getOvers() {
		return overs;
	}

	public void setOvers(int overs) {
		this.overs = overs;
	}

	public double getEconomy() {
		return economy;
	}
	
	public void calculateEconomy() {
		economy = Math.round(((double)runsConceded/overs)*100.0)/100.0;
	}

	@Override
	public String toString() {
		return "Bowler [id=" + id + ", name=" + name + ", runsConceded=" + runsConceded + ", overs=" + overs
				+ ", economy=" + economy + "]";
	}
	
	
}
