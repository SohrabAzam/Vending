package com.pack.model.comparators;

import java.util.Comparator;

import com.pack.model.User;

public class LastNameComparator implements Comparator<User>{
	public int compare(User u1, User u2) {
		return u1.getLastName().compareTo(u2.getLastName());
	}
}
