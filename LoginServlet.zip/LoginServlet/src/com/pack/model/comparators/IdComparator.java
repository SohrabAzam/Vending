package com.pack.model.comparators;

import java.util.Comparator;

import com.pack.model.User;

public class IdComparator implements Comparator<User> {
	public int compare(User u1, User u2) {
		return (u1.getId()-u2.getId());
	}
}
