package com.pack.model;

public class Batsman {
	private int id;
	private String name;
	private int runs;
	private int balls;
	private double strikeRate;

	public Batsman() {
		runs = 0;
		balls = 0;
	}

	public Batsman(int id, String name, int runs, int balls) {
		super();
		this.id = id;
		this.name = name;
		this.runs = runs;
		this.balls = balls;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRuns() {
		return runs;
	}

	public void setRuns(int runs) {
		this.runs = runs;
	}

	public int getBalls() {
		return balls;
	}

	public void setBalls(int balls) {
		this.balls = balls;
	}

	
	public void calculateStrikeRate() {
		strikeRate = Math.round(((double)runs/balls)*100.0)/100.0;
	}

	public double getStrikeRate() {
		return strikeRate;
	}

}
