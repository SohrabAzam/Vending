package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.pack.db.DBCPSourceFactory;
import com.pack.model.User;

public class RegisterDao {
	public boolean registerUser(User user) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		DataSource ds = DBCPSourceFactory.getDataSource();
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("insert into user_table values(?,?,?,?,?,?);");
			ps.setInt(1, user.getId());
			ps.setString(2, user.getUsername());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getFirstName());
			ps.setString(5, user.getLastName());
			ps.setString(6, user.getEmail());
			ps.executeUpdate();
			return true;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
		return false;
	}
}
