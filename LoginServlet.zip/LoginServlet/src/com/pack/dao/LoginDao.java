package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.pack.db.DBCPSourceFactory;
import com.pack.model.User;

public class LoginDao {
	public User validate(User user) throws SQLException {
		String username = user.getUsername();
		String password = user.getPassword();
		User authenticatedUser = new User();
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("select * from user_table where username=? and password=?");
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs != null) {
					int id = rs.getInt("id");
					String firstName = rs.getString("firstName");
					String lastName = rs.getString("lastName");
					String email = rs.getString("email");
					authenticatedUser.setId(id);
					authenticatedUser.setFirstName(firstName);
					authenticatedUser.setLastName(lastName);
					authenticatedUser.setEmail(email);
					authenticatedUser.setUsername(username);
					return authenticatedUser;
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
		return null;

	}
}
