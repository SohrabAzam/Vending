package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.pack.db.DBCPSourceFactory;
import com.pack.model.User;

public class UserDao {
	public int deleteUser(int id) throws SQLException{
		List<User> users = new ArrayList<>();
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		User user = null; 
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("delete from user_table where id=?");
			ps.setInt(1, id);
			return ps.executeUpdate();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(ps!=null)
				ps.close();
			if(rs!=null)
				rs.close();
			if(con!=null)
				con.close();
		}
		return 0;
		
		
	}
	
	public List<User> getUsers() throws SQLException{
		List<User> users = new ArrayList<>();
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		User user = null; 
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("select * from user_table");
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("firstName");
				String lastName = rs.getString("lastName");
				String email = rs.getString("email");
				String username = rs.getString("username");
				user = new User(id, username, firstName, lastName, "", email);
				users.add(user);
				
			}
			return users;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(ps!=null)
				ps.close();
			if(rs!=null)
				rs.close();
			if(con!=null)
				con.close();
		}
		return null;
		
		
	}
}
