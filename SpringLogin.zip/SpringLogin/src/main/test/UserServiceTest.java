package main.test;


import static org.mockito.ArgumentMatchers.any;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.pack.dao.UserDaoImpl;
import com.pack.model.User;
import com.pack.service.UserServiceImpl;


@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
	
	@InjectMocks
	UserServiceImpl service;
	
	@Mock
    UserDaoImpl dao;
	
	@Test
	public void getUser() throws SQLException {
		
		User usernew =new User();
		Mockito.when(dao.getUser(1)).thenReturn(usernew);
		User user = service.getUser(1);
		assertNotNull(user);
		//assertEquals("john", user.getUsername());
	}
	
	@Test
	public void addBalance() throws SQLException {
		
		User usernew = new User();
		usernew.setBalance(100.0);
		Mockito.when(dao.addBalance(any(Double.class), any(User.class))).thenReturn(usernew);
		User user1 = new User();
		user1.setBalance(10.0);
		User user = service.addBalance(90.0, user1);
		assertNotNull(user);
		assertEquals(100.0, user.getBalance(),0.01);
	}
}
