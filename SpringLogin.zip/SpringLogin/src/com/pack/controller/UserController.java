package com.pack.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.Product;
import com.pack.model.User;
import com.pack.service.ProductService;
import com.pack.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;
	@Autowired
	private ProductService productService;

	@RequestMapping(value = "/addBalance", method = RequestMethod.POST)
	public String addBalance(@RequestParam String credit, @RequestParam int id, HttpServletRequest request, ModelMap model)
			throws SQLException {
		
		
		int addCredit = Integer.parseInt(credit);
		
		User user = new User();
		user = service.getUser(id);
		
		user = service.addBalance(addCredit, user);
		System.out.println(user.toString());
		model.addAttribute("user1", user);
		return "addbalance";

	}
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add( @RequestParam int id, ModelMap model) throws SQLException {
		User user = new User();
		user = service.getUser(id);
		model.addAttribute("user1", user);
		return "addbalance";
	}
	
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String product( @RequestParam int id, ModelMap model) throws SQLException {
		User user = new User();
		user = service.getUser(id);
		model.addAttribute("user1", user);
		List<Product> products = productService.getProducts();
		//System.out.println("a");
		model.addAttribute("products", products);
		return "welcome";
	}
	
}
