package com.pack.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.model.Product;
import com.pack.model.User;
import com.pack.service.LoginService;
import com.pack.service.ProductService;

import encryption.Encryptor;

@Controller
public class LoginController {

	@Autowired
	private LoginService service;
	
	@Autowired
	private ProductService productService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String login(ModelMap model) {
		model.addAttribute("user", new User());
		return "login";
	}

	@RequestMapping(value = "/loginProcess", method = RequestMethod.GET)
	public String login(@ModelAttribute("user") User user, ModelMap model, HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		String password = user.getPassword();
		user.setPassword(Encryptor.getMD5EncryptedValue(password));
		
		try {
			User authenticatedUser = service.validate(user);
			if (authenticatedUser != null) {
				session.setAttribute("user", authenticatedUser);
				model.addAttribute("user1", authenticatedUser);
				List<Product> products = productService.getProducts();
				//System.out.println("a");
				model.addAttribute("products", products);
				return "welcome";
			} else {
				System.out.println("Wrong credentials");
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return "login";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping("/login")
	public String login() {
		return "redirect:/";
	}

}
