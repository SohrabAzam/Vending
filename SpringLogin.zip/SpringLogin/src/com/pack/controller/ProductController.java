package com.pack.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.Product;
import com.pack.model.User;
import com.pack.service.ProductService;
import com.pack.service.UserService;

@Controller
public class ProductController {

	@Autowired
	private ProductService service;
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/addStock", method=RequestMethod.GET)
	public String addStock(ModelMap model) throws SQLException {
		List<Product> products = service.getProducts();
		//System.out.println("a");
		model.addAttribute("products", products);
		return "addstock";
	}
	
	@RequestMapping(value = "/addStockProcess", method = RequestMethod.POST)
	public String addBalance(@RequestParam String stockNo, @RequestParam int id, ModelMap model)
			throws SQLException {
		
		
		int stock = Integer.parseInt(stockNo);
		//System.out.println(stock+ " " +id);
		
		Product product = service.getProduct(id);
		//System.out.println(product.toString());
		product = service.addStock(stock, product);
		//user = service.addBalance(id, user);
		return "redirect:/addStock";

	}
	
	@RequestMapping(value = "/buyProduct")
	public String buyProduct(@RequestParam int pid, @RequestParam int id, ModelMap model)
			throws SQLException {
		System.out.println(pid+" "+id);
		
		
		  Product product = service.getProduct(pid);
		  User user = userService.getUser(id);
		  if(user.getBalance()>product.getProdPrice()) {
			  product = service.deductStockByOne(product);
			  if(product != null) {
				  userService.deductBalance(product.getProdPrice(), user);
			  }
		  }
		  
		  
		  
		model.addAttribute("user1", user);
		List<Product> products = service.getProducts();
		model.addAttribute("products", products);
		return "welcome";

	}
}
