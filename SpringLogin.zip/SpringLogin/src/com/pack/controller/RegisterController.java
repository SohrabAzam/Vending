package com.pack.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.model.Product;
import com.pack.model.User;
import com.pack.service.RegisterService;

@Controller
public class RegisterController {
	
	@Autowired
	private RegisterService service;
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String register(ModelMap model) {
		model.addAttribute("user", new User());
		return "register";
	}
	
	@RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	public String registerProcess(@ModelAttribute("user") User user) {
		try {
			boolean registered = service.registerUser(user);
			if (registered != true) {
				return "login";
			} else {
				System.out.println("Wrong credentials");
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return "login";
	}
	
	@RequestMapping(value="/registerProduct", method=RequestMethod.GET)
	public String registerProduct(ModelMap model) {
		model.addAttribute("product", new Product());
		return "addproduct";
	}
	
	@RequestMapping(value = "/registerProductProcess", method = RequestMethod.POST)
	public String registerProductProcess(@ModelAttribute("product") Product product, ModelMap model) {
		
		model.addAttribute("user",new User());
		try {
			boolean registered = service.registerProduct(product);
			if (registered == true) {
				
				return "login";
			} else {
				System.out.println("Wrong input");
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return "login";
	}
}
