package com.pack.db;

import java.util.ResourceBundle;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

public class DBCPSourceFactory {
	public static DataSource getDataSource() {
		ResourceBundle resource = ResourceBundle.getBundle("db");
		BasicDataSource ds = null;
		ds = new BasicDataSource();
		ds.setDriverClassName(resource.getString("db_driver_class"));
		ds.setUrl(resource.getString("db_url"));
		ds.setUsername(resource.getString("db_username"));
		ds.setPassword(resource.getString("db_password"));
		return ds;
	}
}
