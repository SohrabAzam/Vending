package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.pack.db.DBCPSourceFactory;
import com.pack.model.Product;

public class ProductDaoImpl implements ProductDao {
	@Override
	public List<Product> getProducts() throws SQLException{
		List<Product> products= new ArrayList<>();
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		Product product= null; 
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("select * from product_table");
			rs = ps.executeQuery();
			
			while(rs.next()) {
				//System.out.println("hello");
				int id = rs.getInt("id");
				String name = rs.getString("pname");
				String desc = rs.getString("pdesc");
				double price= rs.getDouble("price");
				int stock = rs.getInt("stock");
				product = new Product();
				product.setProdId(id);
				product.setProdName(name);
				product.setProdDescription(desc);
				product.setProdPrice(price);
				product.setStock(stock);
				products.add(product);
				
			}
			return products;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(ps!=null)
				ps.close();
			if(rs!=null)
				rs.close();
			if(con!=null)
				con.close();
		}
		return null;
		
		
	}
	
	public Product getProduct(int id) throws SQLException {

		Product product = new Product();
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int stock = 0;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("select * from product_table where id=?");
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs != null) {

					String name = rs.getString("pname");
					String desc = rs.getString("pdesc");
					double price = rs.getDouble("price");
					stock = rs.getInt("stock");
					product.setProdId(id);
					product.setProdName(name);
					product.setProdDescription(desc);
					product.setProdPrice(price);
					product.setStock(stock);
					//System.out.println(authenticatedUser.toString());
					return product;
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}

		
		return product;
	}
	
	public Product addStock(int addstock, Product product) throws SQLException {
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Product product1 = product;
		
		int stock = product.getStock();
		int updatedStock = stock + addstock;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("update product_table set stock=? where id=?");
			ps.setDouble(1, updatedStock);
			ps.setInt(2, product.getProdId());
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ps != null)
				ps.close();
			if (rs != null)
				rs.close();
			if (con != null)
				con.close();
		}
		product1.setStock(updatedStock);
		return product1;
	}
	
	public Product deductStockByOne(Product product) throws SQLException {
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Product product1 = product;
		
		int stock = product.getStock();
		if(stock==0) {
			return null;
		}
		int updatedStock = stock - 1;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("update product_table set stock=? where id=?");
			ps.setDouble(1, updatedStock);
			ps.setInt(2, product.getProdId());
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ps != null)
				ps.close();
			if (rs != null)
				rs.close();
			if (con != null)
				con.close();
		}
		product1.setStock(updatedStock);
		return product1;
	}
}
