package com.pack.dao;

import java.sql.SQLException;
import java.util.List;

import com.pack.model.Product;
import com.pack.model.User;

public interface ProductDao {

	List<Product> getProducts() throws SQLException;
	
	public Product deductStockByOne(Product product) throws SQLException;
	
	public Product addStock(int addStock, Product product) throws SQLException;
	public Product getProduct(int id) throws SQLException;
}