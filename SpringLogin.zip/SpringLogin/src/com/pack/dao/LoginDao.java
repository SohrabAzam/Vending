package com.pack.dao;

import java.sql.SQLException;

import com.pack.model.User;

public interface LoginDao {
	public User validate(User user) throws SQLException;
}