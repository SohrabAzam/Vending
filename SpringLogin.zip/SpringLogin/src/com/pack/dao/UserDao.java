package com.pack.dao;

import java.sql.SQLException;

import com.pack.model.User;

public interface UserDao {

	public User addBalance(double credit, User user) throws SQLException;
	public User getUser(int id) throws SQLException;
	public User deductBalance(double debit, User user) throws SQLException;

}