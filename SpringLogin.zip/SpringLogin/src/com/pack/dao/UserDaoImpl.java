package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.pack.db.DBCPSourceFactory;
import com.pack.model.User;

public class UserDaoImpl implements UserDao {

	@Override
	public User getUser(int id) throws SQLException {

		User authenticatedUser = new User();
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		double updatedBalance = 0.0;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("select * from user_table where id=?");
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs != null) {

					String firstName = rs.getString("firstName");
					String lastName = rs.getString("lastName");
					String email = rs.getString("email");
					double balance = rs.getDouble("balance");
					String username = rs.getString("username");
					authenticatedUser.setId(id);
					authenticatedUser.setFirstName(firstName);
					authenticatedUser.setLastName(lastName);
					authenticatedUser.setEmail(email);
					authenticatedUser.setUsername(username);
					authenticatedUser.setPassword("");
					authenticatedUser.setBalance(balance);
					//System.out.println(authenticatedUser.toString());
					return authenticatedUser;
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
		System.out.println(updatedBalance);

		
		return authenticatedUser;
	}
	
	public User addBalance(double credit, User user) throws SQLException {
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User user1 = user;
		
		
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("update user_table set balance=? where id=?");
			ps.setDouble(1, credit);
			ps.setInt(2, user.getId());
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ps != null)
				ps.close();
			if (rs != null)
				rs.close();
			if (con != null)
				con.close();
		}
		user1.setBalance(credit);
		return user1;
	}
	
	public User deductBalance(double debit, User user) throws SQLException {
		DataSource ds = DBCPSourceFactory.getDataSource();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User user1 = user;
		
		double balance = user.getBalance();
		double updatedBalance = balance - debit;
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("update user_table set balance=? where id=?");
			ps.setDouble(1, updatedBalance);
			ps.setInt(2, user.getId());
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ps != null)
				ps.close();
			if (rs != null)
				rs.close();
			if (con != null)
				con.close();
		}
		user1.setBalance(updatedBalance);
		return user1;
	}
}
