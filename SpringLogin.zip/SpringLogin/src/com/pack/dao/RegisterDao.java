package com.pack.dao;

import java.sql.SQLException;

import com.pack.model.Product;
import com.pack.model.User;

public interface RegisterDao {

	boolean registerUser(User user) throws SQLException;
	boolean registerProduct(Product product) throws SQLException;
}