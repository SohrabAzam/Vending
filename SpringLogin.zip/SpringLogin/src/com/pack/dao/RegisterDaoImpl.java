package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.pack.db.DBCPSourceFactory;
import com.pack.model.Product;
import com.pack.model.User;

public class RegisterDaoImpl implements RegisterDao {
	@Override
	public boolean registerUser(User user) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		DataSource ds = DBCPSourceFactory.getDataSource();
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("insert into user_table values(?,?,?,?,?,?,?);");
			ps.setInt(1, user.getId());
			ps.setString(2, user.getUsername());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getFirstName());
			ps.setString(5, user.getLastName());
			ps.setString(6, user.getEmail());
			ps.setDouble(7, user.getBalance());
			ps.executeUpdate();
			return true;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
		return false;
	}
	
	public boolean registerProduct(Product product) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		DataSource ds = DBCPSourceFactory.getDataSource();
		try {
			con = ds.getConnection();
			ps = con.prepareStatement("insert into product_table values(?,?,?,?,?);");
			ps.setInt(1, product.getProdId());
			ps.setString(2, product.getProdName());
			ps.setString(3, product.getProdDescription());
			ps.setDouble(4, product.getProdPrice());
			ps.setInt(5, 0);
			ps.executeUpdate();
			return true;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
		return false;
	}
}
