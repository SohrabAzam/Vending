package com.pack.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.ProductDao;
import com.pack.model.Product;
import com.pack.model.User;

public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDao dao;
	
	@Override
	public List<Product> getProducts() throws SQLException {
		return dao.getProducts();
	}

	
	public Product getProduct(int id) throws SQLException {
		return dao.getProduct(id);
	}

	
	public ProductDao getDao() {
		return dao;
	}

	public void setDao(ProductDao dao) {
		this.dao = dao;
	}


	@Override
	public Product addStock(int addStock, Product product) throws SQLException {
		return dao.addStock(addStock, product);
	}


	@Override
	public Product deductStockByOne(Product product) throws SQLException {
		return dao.deductStockByOne(product);
	}
}
