package com.pack.service;

import java.sql.SQLException;
import java.util.List;

import com.pack.model.Product;
import com.pack.model.User;

public interface ProductService {

	List<Product> getProducts() throws SQLException;
	Product addStock(int addStock, Product product) throws SQLException;
	public Product deductStockByOne(Product product) throws SQLException;
	Product getProduct(int id) throws SQLException;
}