package com.pack.service;

import java.sql.SQLException;

import com.pack.model.Product;
import com.pack.model.User;

public interface RegisterService {

	boolean registerUser(User user) throws SQLException;
	
	boolean registerProduct(Product product) throws SQLException;

}