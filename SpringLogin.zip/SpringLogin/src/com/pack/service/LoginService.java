package com.pack.service;

import java.sql.SQLException;

import com.pack.model.User;

public interface LoginService {

	User validate(User user) throws SQLException;

}