package com.pack.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.UserDao;
import com.pack.model.User;

public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao dao;
	
	@Override
	public User getUser(int id) throws SQLException {
		return dao.getUser(id);
	}

	public UserDao getDao() {
		return dao;
	}

	public void setDao(UserDao dao) {
		this.dao = dao;
	}

	@Override
	public User addBalance(double credit, User user) throws SQLException {
		double balance = user.getBalance();
		double updatedBalance = credit + balance;
		return dao.addBalance(updatedBalance, user);
	}

	@Override
	public User deductBalance(double debit, User user) throws SQLException {
		return dao.deductBalance(debit, user);
	}
}
