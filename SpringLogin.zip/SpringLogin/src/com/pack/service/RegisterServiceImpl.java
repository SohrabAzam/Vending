package com.pack.service;

import java.sql.SQLException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.RegisterDao;
import com.pack.model.Product;
import com.pack.model.User;

import encryption.Encryptor;

public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	private RegisterDao dao;
	
	@Override
	public boolean registerUser(User user) throws SQLException {
		String password = user.getPassword();
		int id = generateUniqueId();
		user.setId(id);
		user.setPassword(Encryptor.getMD5EncryptedValue(password));
		return dao.registerUser(user);
	}
	public boolean registerProduct(Product product) throws SQLException {
		int id = generateUniqueId();
		product.setProdId(id);
		return dao.registerProduct(product);
	}
	
	public RegisterDao getDao() {
		return dao;
	}

	public void setDao(RegisterDao dao) {
		this.dao = dao;
	}
	
	public static int generateUniqueId() {      
        UUID idOne = UUID.randomUUID();
        String str=""+idOne;        
        int uid=str.hashCode();
        String filterStr=""+uid;
        str=filterStr.replaceAll("-", "");
        return Integer.parseInt(str);
    }
	
}
