package com.pack.service;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.LoginDao;
import com.pack.model.User;

import encryption.Encryptor;

public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginDao dao;
	@Override
	public User validate(User user) throws SQLException{
		
		return(dao.validate(user));
	}
	public LoginDao getDao() {
		return dao;
	}
	public void setDao(LoginDao dao) {
		this.dao = dao;
	}
	
}
