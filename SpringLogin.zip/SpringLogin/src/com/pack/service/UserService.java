package com.pack.service;

import java.sql.SQLException;

import com.pack.model.User;

public interface UserService {

	User addBalance(double credit, User user) throws SQLException;

	User getUser(int id) throws SQLException;
	
	public User deductBalance(double debit, User user) throws SQLException; 

}