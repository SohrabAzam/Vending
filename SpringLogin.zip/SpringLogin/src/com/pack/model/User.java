package com.pack.model;

import org.springframework.context.annotation.Scope;

@Scope("session")
public class User implements Comparable<User>{

	private int id;
	private String username;
	private String firstName;
	private String lastName;
	private String password;
	private String email;
	private double balance;
	
	public User() {
		
	}

	public User(int id, String username, String firstName, String lastName, String password, String email) {
		super();
		this.id = id;
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public String getFirstName() {
		return firstName;
	}

	public int getId() {
		return id;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPassword() {
		return password;
	}

	public String getUsername() {
		return username;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	/*
	 * public boolean validate() throws InvalidNameException, InvalidEmailException,
	 * InvalidUsernameException, InvalidPasswordException { if
	 * (!Pattern.matches("[a-zA-Z]+", this.getFirstName())) { throw(new
	 * InvalidNameException("Invalid First Name")); } else
	 * if(!Pattern.matches("[a-zA-Z]+", this.getLastName())) { throw(new
	 * InvalidNameException("Invalid Last Name")); } else
	 * if(!Pattern.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" +
	 * "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", this.getEmail())) {
	 * throw(new InvalidEmailException("Invalid Email")); } else
	 * if(!Pattern.matches("[a-zA-Z0-9]{3,}", this.getUsername())) { throw(new
	 * InvalidUsernameException("Invalid Username")); } else
	 * if(!Pattern.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})",
	 * this.getPassword())) { throw(new
	 * InvalidPasswordException("Invalid Password")); }
	 * 
	 * return true; }
	 */

	@Override
	public int compareTo(User user) {
		// TODO Auto-generated method stub
		return user.getFirstName().compareTo(this.getFirstName());
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", password=" + password + ", email=" + email + ", balance=" + balance + "]";
	}

	
}
